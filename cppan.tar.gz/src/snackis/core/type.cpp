#include "snackis/core/error.hpp"
#include "snackis/core/type.hpp"

namespace snackis {
  BasicType::BasicType(const str &name): name(name) { }
}
