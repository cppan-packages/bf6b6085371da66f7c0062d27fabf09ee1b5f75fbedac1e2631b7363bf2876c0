#include "opt.hpp"

namespace snackis {
  const std::nullopt_t nullopt(std::nullopt);
}
