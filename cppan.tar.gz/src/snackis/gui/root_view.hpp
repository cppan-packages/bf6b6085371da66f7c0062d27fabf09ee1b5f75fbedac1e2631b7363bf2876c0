#ifndef SNACKIS_GUI_ROOT_VIEW_HPP
#define SNACKIS_GUI_ROOT_VIEW_HPP

#include <vector>

#include "snackis/gui/view.hpp"

namespace snackis {
namespace gui {
  struct RootView: View {
    RootView(Ctx &ctx);
  };
}}

#endif
