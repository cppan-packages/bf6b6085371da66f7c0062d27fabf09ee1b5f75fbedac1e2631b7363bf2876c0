#include "snackis/gui/root_view.hpp"

namespace snackis {
namespace gui {
  RootView::RootView(Ctx &ctx): View(ctx, "")
  { }
}}
