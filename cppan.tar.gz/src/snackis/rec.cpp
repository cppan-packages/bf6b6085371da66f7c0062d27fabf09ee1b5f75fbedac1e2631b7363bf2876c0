#include "snackis/rec.hpp"

namespace snackis {
  Rec::Rec(Ctx &ctx): ctx(ctx)
  { }
}
